/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencija;

import java.awt.Graphics2D;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.*;


/**
 *
 * @author LENA
 */
public class Vodic extends javax.swing.JFrame {

    
    public Vodic() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jRadioButton2 = new javax.swing.JRadioButton();
        jRadioButton3 = new javax.swing.JRadioButton();
        jRadioButton4 = new javax.swing.JRadioButton();
        jRadioButton1 = new javax.swing.JRadioButton();
        jRadioButton5 = new javax.swing.JRadioButton();
        jRadioButton6 = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("V o d i c");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jRadioButton2.setText("2");
        jRadioButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton2MouseClicked(evt);
            }
        });

        jRadioButton3.setText("3");
        jRadioButton3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton3MouseClicked(evt);
            }
        });

        jRadioButton4.setText("4");
        jRadioButton4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton4MouseClicked(evt);
            }
        });

        jRadioButton1.setText("1");
        jRadioButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton1MouseClicked(evt);
            }
        });

        jRadioButton5.setText("5");
        jRadioButton5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton5MouseClicked(evt);
            }
        });

        jRadioButton6.setText("6");
        jRadioButton6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jRadioButton6MouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jRadioButton2, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jRadioButton4, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jRadioButton3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jRadioButton1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jRadioButton5, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jRadioButton6, javax.swing.GroupLayout.Alignment.TRAILING)))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(198, 198, 198)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(254, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(jRadioButton1)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton2)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton3)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton4)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton5)
                .addGap(18, 18, 18)
                .addComponent(jRadioButton6)
                .addGap(0, 230, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(89, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(100, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        // TODO add your handling code here:
        
        Graphics2D gfx = (Graphics2D)jPanel1.getGraphics();
        gfx.drawString("Putovanja",230,80);
        gfx.drawString("Slike",545,60);
        gfx.drawString("Destinacija 1 : Viktorijini Vodopadi - 400$",160,110);
        gfx.drawString("Vodopade dostojne imerijalne slave Britanci su po kraljici nazvali",50,130);
        gfx.drawString("Viktorijinim, mada vise odgovara staro africko ime Mosi o Tunja",50,145);
        
        gfx.drawString("Destinacija 2 : Crveno more - 400$",160,170);
        gfx.drawString("U većem delu godine, Crveno more, kao i većina mora ima plavičastu boju,",50,190);
        gfx.drawString("ali za vreme cvetanja crvenih algi (Trichodesmium erythaeum), voda dobija crvenkastu boju.",50,205);
        
        gfx.drawString("Destinacija 3 : Mombasa - 350$",160,230);
        gfx.drawString("Vetrovi u Mombasi se pola godine krecu sa severoistoka ka jugozapadu",50,250);
        gfx.drawString("da bi iducih pola godine duvali u suprotnom smeru. Otuda naziv Trgovacki vetrovi",50,265);
        
        gfx.drawString("Destinacija 4 : Zanzibar - 300$",160,290);
        gfx.drawString("Iznikao na koralnoj podlozi, Zanzibar je poznat kao ostrvo zacina: vanila, biber, proso, pirinac,",50,310);
        gfx.drawString("africke krtolaste bilje: kasava i jam. Postoji ipak bitna razlika jer nema vise pijace robova.",50,325);
        
        gfx.drawString("Destinacija 5 : Madagaskar - 600$",160,350);
        gfx.drawString("Ostrvo svakako, ako kakvo? Veliko kao Franciska, Belgija, Holandija i Luksemburg zajedno",50,370);
        gfx.drawString("Na ovom prostoru zivi ne manje od 7 miliona ljudi i isto toliko goveda",50,385);
        gfx.drawString("Na Madagaskaru poznato je drvo Baobab - korenje izvrnuto naopako ",50,400);
        
        gfx.drawString("Destinacija 6 : Kilimadzaro - 800$",160,425);
        gfx.drawString("Pleme Vačagi na obroncima Kilimandzara vec godinama za potrebe planinskih druzina",50,445);
        gfx.drawString("obezbedjuje vodice i nosace. Sa vrecama od 20kg oni prevale put od",50,460);
        gfx.drawString("stotinu kilometara i ko zna po koji put oni se uspinju na krov Afrike",50,475);
        
              
       

       
    }//GEN-LAST:event_jButton1MouseClicked

    private void jRadioButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton1MouseClicked
        
        BufferedImage image1 = null; 
        BufferedImage image2 = null;
        
        String path1 = "vikrorijini_vodopadi.jpg";
        String path2 = "viktorijini_vodopadi2.jpg";
        
        File file1 = new File(path1);
        try {
            image1 = ImageIO.read(file1);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file2 = new File(path2);
        try {
            image2 = ImageIO.read(file2);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        JLabel label1 = new JLabel(new ImageIcon(image1));
        JLabel label2 = new JLabel(new ImageIcon(image2));
        
        
        JFrame f1 = new JFrame();
        JFrame f2 = new JFrame();
        
        
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.getContentPane().add(label1);
        f1.pack();
        f1.setLocation(200,200);
        f1.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.getContentPane().add(label2);
        f2.pack();
        f2.setLocation(300,200);
        f2.setVisible(true);
        
    }//GEN-LAST:event_jRadioButton1MouseClicked

    private void jRadioButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton2MouseClicked
        BufferedImage image1 = null; 
        BufferedImage image2 = null;
        BufferedImage image3 = null;
        String path1 = "Mapa_Crvenomore.jpg";
        String path2 = "Ronjejne_Crvenomore.jpg";
        String path3 = "Korali_Crvenomore.jpg";
        
        File file1 = new File(path1);
        try {
            image1 = ImageIO.read(file1);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file2 = new File(path2);
        try {
            image2 = ImageIO.read(file2);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file3 = new File(path3);
        try {
            image3 = ImageIO.read(file3);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        JLabel label1 = new JLabel(new ImageIcon(image1));
        JLabel label2 = new JLabel(new ImageIcon(image2));
        JLabel label3 = new JLabel(new ImageIcon(image3));
        
        JFrame f1 = new JFrame();
        JFrame f2 = new JFrame();
        JFrame f3 = new JFrame();
        
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.getContentPane().add(label1);
        f1.pack();
        f1.setLocation(200,100);
        f1.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.getContentPane().add(label2);
        f2.pack();
        f2.setLocation(300,200);
        f2.setVisible(true);
        f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f3.getContentPane().add(label3);
        f3.pack();
        f3.setLocation(400,300);
        f3.setVisible(true);
    }//GEN-LAST:event_jRadioButton2MouseClicked

    private void jRadioButton3MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton3MouseClicked
        BufferedImage image1 = null; 
        BufferedImage image2 = null;
        BufferedImage image3 = null;
        BufferedImage image4 = null;
        
        String path1 = "Mapa_Mombasa.gif";
        String path2 = "Nacionalnipark_Marine_Mombasa.jpg";
        String path3 = "Plaza_Mombasa.jpg";
        String path4 = "Trgovackivetrovi3_Mombasa.jpg";
        
        File file1 = new File(path1);
        try {
            image1 = ImageIO.read(file1);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file2 = new File(path2);
        try {
            image2 = ImageIO.read(file2);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file3 = new File(path3);
        try {
            image3 = ImageIO.read(file3);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file4 = new File(path4);
        try {
            image4 = ImageIO.read(file4);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        JLabel label1 = new JLabel(new ImageIcon(image1));
        JLabel label2 = new JLabel(new ImageIcon(image2));
        JLabel label3 = new JLabel(new ImageIcon(image3));
        JLabel label4 = new JLabel(new ImageIcon(image4));
        
        JFrame f1 = new JFrame();
        JFrame f2 = new JFrame();
        JFrame f3 = new JFrame();
        JFrame f4 = new JFrame();
        
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.getContentPane().add(label1);
        f1.pack();
        f1.setLocation(200,100);
        f1.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.getContentPane().add(label2);
        f2.pack();
        f2.setLocation(300,200);
        f2.setVisible(true);
        f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f3.getContentPane().add(label3);
        f3.pack();
        f3.setLocation(400,300);
        f3.setVisible(true);
        f4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f4.getContentPane().add(label4);
        f4.pack();
        f4.setLocation(500,400);
        f4.setVisible(true);
    }//GEN-LAST:event_jRadioButton3MouseClicked

    private void jRadioButton4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton4MouseClicked
        BufferedImage image1 = null; 
        BufferedImage image2 = null;
        BufferedImage image3 = null;
        BufferedImage image4 = null;
        
        String path1 = "Luka_Zanzibar.jpg";
        String path2 = "Mapa_Zanzibar.gif";
        String path3 = "Marketslave_Zanzibar.jpg";
        String path4 = "Pijacazacina_Zanzibar.jpg";
        
        File file1 = new File(path1);
        try {
            image1 = ImageIO.read(file1);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file2 = new File(path2);
        try {
            image2 = ImageIO.read(file2);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file3 = new File(path3);
        try {
            image3 = ImageIO.read(file3);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file4 = new File(path4);
        try {
            image4 = ImageIO.read(file4);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        JLabel label1 = new JLabel(new ImageIcon(image1));
        JLabel label2 = new JLabel(new ImageIcon(image2));
        JLabel label3 = new JLabel(new ImageIcon(image3));
        JLabel label4 = new JLabel(new ImageIcon(image4));
        
        JFrame f1 = new JFrame();
        JFrame f2 = new JFrame();
        JFrame f3 = new JFrame();
        JFrame f4 = new JFrame();
        
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.getContentPane().add(label1);
        f1.pack();
        f1.setLocation(200,100);
        f1.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.getContentPane().add(label2);
        f2.pack();
        f2.setLocation(300,200);
        f2.setVisible(true);
        f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f3.getContentPane().add(label3);
        f3.pack();
        f3.setLocation(400,300);
        f3.setVisible(true);
        f4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f4.getContentPane().add(label4);
        f4.pack();
        f4.setLocation(500,400);
        f4.setVisible(true);
    }//GEN-LAST:event_jRadioButton4MouseClicked

    private void jRadioButton5MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton5MouseClicked
        BufferedImage image1 = null; 
        BufferedImage image2 = null;
        BufferedImage image3 = null;
        BufferedImage image4 = null;
        
        String path1 = "Mapa_Madagaskar.gif";
        String path2 = "RanomafanaNacionalniPrak_Madagaskar2.jpg";
        String path3 = "Kisnasuma_Madagaskar.jpg";
        String path4 = "Baobab2_Madagaskar.jpg";
        
        File file1 = new File(path1);
        try {
            image1 = ImageIO.read(file1);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file2 = new File(path2);
        try {
            image2 = ImageIO.read(file2);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file3 = new File(path3);
        try {
            image3 = ImageIO.read(file3);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file4 = new File(path4);
        try {
            image4 = ImageIO.read(file4);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        JLabel label1 = new JLabel(new ImageIcon(image1));
        JLabel label2 = new JLabel(new ImageIcon(image2));
        JLabel label3 = new JLabel(new ImageIcon(image3));
        JLabel label4 = new JLabel(new ImageIcon(image4));
        
        JFrame f1 = new JFrame();
        JFrame f2 = new JFrame();
        JFrame f3 = new JFrame();
        JFrame f4 = new JFrame();
        
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.getContentPane().add(label1);
        f1.pack();
        f1.setLocation(200,100);
        f1.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.getContentPane().add(label2);
        f2.pack();
        f2.setLocation(300,200);
        f2.setVisible(true);
        f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f3.getContentPane().add(label3);
        f3.pack();
        f3.setLocation(400,300);
        f3.setVisible(true);
        f4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f4.getContentPane().add(label4);
        f4.pack();
        f4.setLocation(500,400);
        f4.setVisible(true);
    }//GEN-LAST:event_jRadioButton5MouseClicked

    private void jRadioButton6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jRadioButton6MouseClicked
        BufferedImage image1 = null; 
        BufferedImage image2 = null;
        BufferedImage image3 = null;
        String path1 = "Mapa_Kilimandzaro.jpg";
        String path2 = "Kamp_Kilimandzaro.jpg";
        String path3 = "Kilimandzaro2.jpg";
        
        File file1 = new File(path1);
        try {
            image1 = ImageIO.read(file1);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file2 = new File(path2);
        try {
            image2 = ImageIO.read(file2);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        File file3 = new File(path3);
        try {
            image3 = ImageIO.read(file3);
        } catch (IOException ex) {
            Logger.getLogger(Vodic.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        JLabel label1 = new JLabel(new ImageIcon(image1));
        JLabel label2 = new JLabel(new ImageIcon(image2));
        JLabel label3 = new JLabel(new ImageIcon(image3));
        
        JFrame f1 = new JFrame();
        JFrame f2 = new JFrame();
        JFrame f3 = new JFrame();
        
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f1.getContentPane().add(label1);
        f1.pack();
        f1.setLocation(200,100);
        f1.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f2.getContentPane().add(label2);
        f2.pack();
        f2.setLocation(300,200);
        f2.setVisible(true);
        f3.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f3.getContentPane().add(label3);
        f3.pack();
        f3.setLocation(400,300);
        f3.setVisible(true);
    }//GEN-LAST:event_jRadioButton6MouseClicked

    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vodic.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vodic.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vodic.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vodic.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Vodic().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JRadioButton jRadioButton2;
    private javax.swing.JRadioButton jRadioButton3;
    private javax.swing.JRadioButton jRadioButton4;
    private javax.swing.JRadioButton jRadioButton5;
    private javax.swing.JRadioButton jRadioButton6;
    // End of variables declaration//GEN-END:variables
}
