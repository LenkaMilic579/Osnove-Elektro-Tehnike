/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencija;

/**
 *
 * @author LENA
 */
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Agencija {


    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        
        Vodic frame = new Vodic();
        frame.setVisible(true);
        
        
        int sss=0;
        int i,j;
        
        String[] baza_imena;
        int[] baza_lozinka;
       
        ArrayList<String> destinacije = new ArrayList<String>(Arrays.asList("R", "Crveno more", "R", "Zanzibar", "Madagaskar", "Kilimandzaro"));
       
        
        baza_imena = new String[100];
        baza_lozinka = new int[100];
        
        

        
        
        //neka stoje neki podaci...
        baza_imena[0] = "Marko";
        baza_lozinka[0] = 1;
        baza_imena[1] = "Lenka";
        baza_lozinka[1] = 2;
         baza_imena[2] = "Ivana";
        baza_lozinka[2] = 3;
        baza_imena[3] = "Vlada";
        baza_lozinka[3] = 4;
         baza_imena[4] = "Nikola";
        baza_lozinka[4] = 11;
        baza_imena[5] = "Luka";
        baza_lozinka[5] = 22;
         baza_imena[6] = "Aleksandar";
        baza_lozinka[6] = 123;
        baza_imena[7] = "Jovana";
        baza_lozinka[7] = 33;
        
        for (int k=2; k < baza_imena.length; k++)
        {   
            baza_imena[k]= null;
            baza_lozinka[k]=0;
        }
        
        System.out.println("Dobrodosli u Agenciju za putovanja. Napravite novi nalog, ");
        System.out.println("Unesite svoje ime: ");
        String ime = scan.next();
        
        System.out.println("Unesite svoju lozinku: ");
        int lozinka;
        lozinka = scan.nextInt();
        Inteligentno_bice osoba = new Inteligentno_bice(ime,lozinka); 
        
        int h2=0;
            
            

            
            for(i=0; i< baza_imena.length; i++)
            {
                if ((baza_imena[i] == null)&& (h2 != 1))
                {
                    baza_imena[i] = osoba.ime;
                    baza_lozinka[i] = osoba.lozinka;
                    h2 = 1;
                    System.out.println("Uspesno ste napravili svoj nalog u Agenciji za putovanja");
                    
                    
                }
            }
            
            
   
    
    osoba.racun = new Racun_u_Banci(1000);
    osoba.rez = new Rezervacija(destinacije);
    
  
   
    
    System.out.println("U Vodicu mozete videti destinacije koje su numerisane od 1 do 6, kao i cenu putovanja. ");
    
    System.out.println("Vase stanje na racunu ne moze biti ispod 50 dolara. Da li zelite videti stanje na Vasem racunu?");
    System.out.println("Ukucajte 1 za DA ili 0 za NE: ");
   
        long sifra = scan.nextLong();
        if (sifra==1)
        {
         System.out.println("Iznos Vaseg racuna je: " + osoba.racun.prihod);
        }
        
         int kkk = 0;
         boolean vrati = false;
         
         
         
         while(vrati != true)
         { 
         System.out.println("Za rezervaciju unesite broj za zeljenu destinaciju koji se nalazi u Vodicu");
         System.out.println("Ovo ce se ponavljati dok ne upisete pravilnu, postojecu cifru");
         System.out.println("Unesite cifru: ");
         
         kkk = scan.nextInt();
         if((kkk<1) || (kkk>6))
         {
             System.out.println("Uneli ste nedozvoljenu cifru.");
         }
         else if((kkk>=1) && (kkk<=6))
                 {vrati = osoba.rez.reserve(kkk);}
         }
         
         
          if (vrati) 
          {
             System.out.println("Rezervacija: " + vrati);
             System.out.println("Rezervacija je uspesno obavljena");
             sss = osoba.racun.uplati(kkk);
             if (sss == 0) { 
                 System.out.println("Na racunu nemate dovoljno novca. Min iznos = 50$. Rezervacija ce biti ponistena.");
                 System.out.println("Molimo vas da ponovo pokrenete program");
             }
             if (sss == 1)
            { 
              int d;
              d = osoba.racun.prihod;
              System.out.println("Vas racun sada iznosi: " + osoba.racun.prihod);
              System.out.println("\t\nTo bi bilo sve! Vas avion polece u 20:00 h ! Srecan put!");
          }
                    
              
            }
     
    
}}
