/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencija;

/**
 *
 * @author LENA
 */
public class Racun_u_Banci {
        int prihod; 


public int uplati(int ind)
{
    int a;
    a = prihod;
    if(a>350) //provera - najmanja cena destinacija = 350
        {
        if((ind<1) && (ind>6)) return 0;
        if(ind==1) 
        {
            prihod = prihod - 400;
            if (prihod > 50) return 1;
            else return 0;
        }
        if(ind==2) 
            {
            prihod = prihod - 400;
            if (prihod > 50) return 1;
            else return 0;
        }
        if(ind==3) 
            {
            prihod = prihod - 350;
            if (prihod > 50) return 1;
            else return 0;
        }
        if(ind==4) 
            {
            prihod = prihod - 300;
            if (prihod > 50) return 1;
            else return 0;
        }
        if(ind==5) 
            {
            prihod = prihod - 600;
            if (prihod > 50) return 1;
            else return 0;
        }
        if(ind==6) 
            {
            prihod = prihod - 1000;
            if (prihod > 50) return 1;
            else return 0;
        }
        
        }  
    else return 0;
    return 0;
}

public Racun_u_Banci(int stanje)
{
    prihod = stanje;
}


}
