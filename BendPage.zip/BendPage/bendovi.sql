-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 19, 2018 at 01:21 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bendovi`
--

-- --------------------------------------------------------

--
-- Table structure for table `albumi`
--

DROP TABLE IF EXISTS `albumi`;
CREATE TABLE IF NOT EXISTS `albumi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imebenda` varchar(255) NOT NULL,
  `imealbuma` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `albumi`
--

INSERT INTO `albumi` (`id`, `imebenda`, `imealbuma`) VALUES
(30, 'Brigand', 'Daleko je Vavilon'),
(29, 'Brigand', 'ZapleÅ¡imo GreÅ¡nici'),
(27, 'Dead Joker', 'Act II'),
(26, 'Dead Joker', 'Venture'),
(25, 'Steel Hornet', 'Hornet of Steel'),
(31, 'My Own Word', 'Breaking Out');

-- --------------------------------------------------------

--
-- Table structure for table `clanovi`
--

DROP TABLE IF EXISTS `clanovi`;
CREATE TABLE IF NOT EXISTS `clanovi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imebenda` varchar(255) NOT NULL,
  `clan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clanovi`
--

INSERT INTO `clanovi` (`id`, `imebenda`, `clan`) VALUES
(24, 'Steel Hornet', 'Dragoslav RistiÄ‡'),
(23, 'Steel Hornet', 'Djordje PaunoviÄ‡'),
(22, 'Steel Hornet', 'DuÅ¡an AndjelkoviÄ‡'),
(21, 'Steel Hornet', 'MiloÅ¡ StoÅ¡iÄ‡ '),
(20, 'Steel Hornet', 'Radisav GrboviÄ‡'),
(25, 'Dead Joker', 'Zlaja'),
(26, 'Dead Joker', 'Pedja'),
(27, 'Dead Joker', 'Gogec'),
(28, 'Dead Joker', 'Marko'),
(29, 'Dead Joker', 'Copa'),
(30, 'My Own Word', 'Stefan MikiÄ‡'),
(31, 'My Own Word', 'Marko LukiÄ‡'),
(32, 'My Own Word', 'Stefan VeliÄkoviÄ‡'),
(33, 'My Own Word', 'Mladen MirÄiÄ‡ ');

-- --------------------------------------------------------

--
-- Table structure for table `linkovi`
--

DROP TABLE IF EXISTS `linkovi`;
CREATE TABLE IF NOT EXISTS `linkovi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imebenda` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `linkovi`
--

INSERT INTO `linkovi` (`id`, `imebenda`, `link`) VALUES
(12, 'Dead Joker', 'https://www.facebook.com/Dead-Joker-295207790593399/'),
(10, 'Steel Hornet', 'https://www.facebook.com/SteelHornetHeavySpeed/'),
(11, 'Steel Hornet', 'https://www.youtube.com/watch?v=Lgn5lpljs0I'),
(13, 'Dead Joker', 'https://www.instagram.com/deadjokerband_official/'),
(14, 'Dead Joker', 'https://www.youtube.com/watch?v=M0hAqVHY76Y'),
(15, 'Brigand', 'https://www.facebook.com/Brigandband/'),
(16, 'Brigand', 'https://www.youtube.com/watch?v=l8HQU0sfK0c'),
(17, 'My Own Word', 'https://www.facebook.com/My-Own-Word-2117333998499670/'),
(18, 'My Own Word', 'https://www.instagram.com/myownword80/'),
(19, 'My Own Word', 'https://www.youtube.com/watch?v=QiAgzhzi2FQ');

-- --------------------------------------------------------

--
-- Table structure for table `pesme`
--

DROP TABLE IF EXISTS `pesme`;
CREATE TABLE IF NOT EXISTS `pesme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imealbuma` varchar(255) NOT NULL,
  `imepesme` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=126 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pesme`
--

INSERT INTO `pesme` (`id`, `imealbuma`, `imepesme`) VALUES
(95, 'Act II', 'Uncertainty That Obsess'),
(94, 'Act II', 'Huge'),
(93, 'Act II', 'Junction Fright Sanctifies'),
(92, 'Act II', 'Play Mysterious'),
(91, 'Act II', 'Jokerâ€™s Foreplay'),
(90, 'Venture', 'Calling Astray'),
(89, 'Venture', 'Deplore the Loss'),
(88, 'Venture', 'Before You Accuse Me'),
(87, 'Venture', 'Rule the Chimera Dread'),
(86, 'Venture', 'Lives Undone'),
(85, 'Venture', 'Procreation Event'),
(84, 'Hornet of Steel', 'Hornets of Steel'),
(83, 'Hornet of Steel', 'No human rights'),
(82, 'Hornet of Steel', 'Master'),
(96, 'Act II', 'Theurgy Terminus'),
(97, 'Act II', 'Wallowing in Vortex'),
(98, 'Act II', 'Explosion of the Moments'),
(102, 'ZapleÅ¡imo GreÅ¡nici', 'Srpski Rok'),
(103, 'ZapleÅ¡imo GreÅ¡nici', 'Kriptid i Alisa'),
(104, 'ZapleÅ¡imo GreÅ¡nici', 'Samostrel'),
(105, 'ZapleÅ¡imo GreÅ¡nici', 'MeseÄev Kum'),
(106, 'ZapleÅ¡imo GreÅ¡nici', 'Samervind'),
(107, 'ZapleÅ¡imo GreÅ¡nici', 'Voleo Sam Te'),
(108, 'ZapleÅ¡imo GreÅ¡nici', 'ZapleÅ¡imo GreÅ¡nici'),
(109, 'ZapleÅ¡imo GreÅ¡nici', 'Metak S` Mojim Imenom'),
(110, 'ZapleÅ¡imo GreÅ¡nici', 'Heroj'),
(111, 'ZapleÅ¡imo GreÅ¡nici', 'Tri NoÄ‡i (feat. Jarboe)'),
(112, 'Daleko je Vavilon', 'Most je preÅ¡ao reku'),
(113, 'Daleko je Vavilon', 'Pravo pa desno'),
(114, 'Daleko je Vavilon', 'Daleko je Vavilon'),
(115, 'Daleko je Vavilon', 'Sloboda u tvojim oÄima'),
(116, 'Daleko je Vavilon', 'Kardio'),
(117, 'Daleko je Vavilon', 'Sunce od krvi'),
(118, 'Daleko je Vavilon', 'VaÅ¡ingtonova ulica'),
(119, 'Daleko je Vavilon', 'Duhovi'),
(120, 'Daleko je Vavilon', 'Bogomoljka'),
(121, 'Daleko je Vavilon', 'NereÄeno'),
(122, 'Daleko je Vavilon', 'Centurion'),
(123, 'Breaking Out', 'Breaking out'),
(124, 'Breaking Out', 'All over again'),
(125, 'Breaking Out', 'After all');

-- --------------------------------------------------------

--
-- Table structure for table `tabela`
--

DROP TABLE IF EXISTS `tabela`;
CREATE TABLE IF NOT EXISTS `tabela` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_vlasnika` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `grad` varchar(255) NOT NULL,
  `zanr` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `godosnivanja` int(255) NOT NULL,
  `biografija` varchar(5000) NOT NULL,
  `slika` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tabela`
--

INSERT INTO `tabela` (`id`, `id_vlasnika`, `ime`, `grad`, `zanr`, `status`, `godosnivanja`, `biografija`, `slika`) VALUES
(24, 9, 'Steel Hornet', 'Kragujevac', 'Speed Metal', 'aktivan', 2014, 'Steel Hornet je kragujevacki heavy/speed metal bend nastao sredinom 2014. godine sa namerom da svira stari dobri hevi/spid metal,uglavnom pod uticajem nemacke skole.Bend svira poznate svari ovog zanra,ali se uveliko radi i na autorskim stvarima koje ce bend predstaviti pocetkom novembra. Bend trenutno trazi izdavacku kucu.', '14909897_1678677372423352_4748962818695385677_n.jpg'),
(25, 9, 'Dead Joker', 'Kragujevac', 'Death Metal', 'aktivan', 1991, 'Dead Joker je osnovan 1990. godine, da bi veÄ‡ godinu kasnije snimili demo Cannibalistic Dissection. Prvi, kasetni album Venture je izaÅ¡ao 1994. godine za West Force, 1997. godine izdat i za IDM Music, nakon Äega se bend i zvaniÄno raspao. 2001. sa bonus pesmama debi album reizdat je na CD-u za nemaÄki Klasma Records pod nazivom Act II. 1997.', '12994502_946506552130183_5385445301797769465_n.jpg'),
(26, 9, 'Brigand', 'PanÄevo', 'Alt rock', 'aktivan', 2011, 'BRIGAND je alternativni rok sastav koji radi na relaciji Beograd/PanÄevo, oformljen 2011. godine od strane Velibora NikoliÄ‡a (ex-Jewy Sabatay). Postavu Äine i Ilija KojoviÄ‡ (bas) i MIlan SariÄ‡(bubanj). Posle dva objavljena singla (Malarme, Okovan), bend je u septembru 2013. objavio svoj prvi studijski album, â€žZapleÅ¡imo GreÅ¡nici\". U junu 2015. bend objavljuje svoj novi singl \"Zmijsko Ulje\". Drugi studijski album, \"Daleko Je Vavilon\", izaÅ¡ao je 26. februara 2017. ', '17499157_1469777086380505_5559899619944329684_n.jpg'),
(27, 10, 'My Own Word', 'Kragujevac', 'Pop punk', 'aktivan', 2015, 'KragujevÄki bend, oformljen u Aprilu 2015. godine. Å½anr koji sviraju, predstavlja kombinaciju Pop punk, Melodic hardcore i Alternative rock zvuka. Na samom poÄetku 2018. godine bend zvaniÄno menja ime u \"My Own Word\", do tada ime benda, bilo je \"Prank\". Sam poÄetak je bio jako kritiÄan i nestabilan zbog Äeste promene Älanova, Å¡to je trajalo, do Oktobra, iste godine. U decembru 2015-e godine bend je imao prvi celoveÄernji koncert. Naredne godine bend ima razne koncerte i nastupe, a krajem godine objavljuju prvi single pod nazivom ,,Breaking outâ€™â€™. Kao veÄ‡i uspeh, moglo bi se izdvojiti uÄeÅ¡Ä‡e na festivalu \"MEGAFON Music Live 05\", u Kragujevcu 2017. godine.', '26113943_2117334168499653_331152525546779475_n.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `slika_ime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `slika_ime`) VALUES
(9, 'Schwarzenegger', 'schw@gmail.com', 'schw', 'svarci.jpg'),
(10, 'David Icke', 'david@yahoo.com', 'dav', 'David-Icke-833229.jpg'),
(6, 'admin', 'admin@gmail.com', 'admin', '1.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
