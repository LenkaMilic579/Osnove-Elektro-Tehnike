<html>
<head>
<title>MAJBENDPEJDz</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">




<style>
body {font-family: "Lato", sans-serif}
body  {
    background-image: url("slika1.jpg");
    background-color: #cccccc;
    background-repeat: no-repeat;
    background-attachment: fixed;
}
body {
    font-family: Arial;
}



form.example input[type=text] {
    padding: 20px;
    font-size: 25px;
    border: 1px solid grey;
    float: center;
    width: 80%;
    background: #f1f1f1;
}

form.example button {
    float: right;
    width: 20%;
    padding: 30px;
    background: black;
    color: white;
    font-size: 17px;
    border: 1px solid grey;
    border-left: none;
    cursor: pointer;
}

form.example button:hover {
    background: grey;
}

form.example::after {
    content: "";
    clear: both;
    display: table;
}
.avatar {
    vertical-align: middle;
    width: 25px;
    height: 25px;
    border-radius: 50%;
}
.topnav-right {
  float: right;
}

</style>
</head>
<body>

<?php
session_start();


$username = $_SESSION["ime"];
$id = $_SESSION["id"];

$con = mysqli_connect("localhost","root","");
		
			mysqli_select_db($con,"bendovi");
			$qry = "SELECT * FROM users WHERE username = '".$username."'";
			$result1 = mysqli_query($con, $qry);
			if($result1 === FALSE) { die(mysqli_error($con));} 
			while($row = mysqli_fetch_array($result1))
			{
				$slika_ime = $row['slika_ime'];	
			}
			mysqli_close($con);
			
				
			
?>
<div class="w3-top">
  <div class="w3-bar w3-black w3-card">
    <a class="w3-bar-item w3-button w3-padding-large w3-hide-medium w3-hide-large w3-right" href="javascript:void(0)" onclick="myFunction()" title="Toggle Navigation Menu"><i class="fa fa-bars"></i></a>
    <a href="search1.php" class="w3-bar-item w3-button w3-padding-large">PRETRAGA</a>
    <div class="w3-dropdown-hover w3-hide-small">
      <button class="w3-padding-large w3-button" title="More">BEND <i class="fa fa-caret-down"></i></button>     
      <div class="w3-dropdown-content w3-bar-block w3-card-4">
        <a href="zanr1.php" class="w3-bar-item w3-button">Žanr</a>
        <a href="Grad1.php" class="w3-bar-item w3-button">Grad</a>
        <a href="ABC1.php" class="w3-bar-item w3-button">Abecedno</a>
      </div>
    </div>
    <a href="Korisnici1.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">KORISNICI</a>

	<div class="topnav-right">
<a href="mojprofil.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small"><img src="<?php echo $slika_ime; ?>" alt="Avatar" class="avatar"><?php echo " ". $username; ?></a>
 
<a href="search.php" class="w3-bar-item w3-button w3-padding-large w3-hide-small">IZLOGUJ SE</a> 
</div>
	<img src="majbendpejdz.png" style="width:400px;height:50px; margin: 0px 0px 0px 395px; " >
  </div>
</div>

</body>
</html>
