<?php 

	
	//if (isset($_POST['submit']))
	//{
		$albumi = array();
		$ans1= 'Da';
		$ans2= 'Ne';
		$answer = $_POST['izbrisi']; //value of button1 or button2 in answer
		$imeslike = $_POST['hiddenimage'];
		if ($answer == $ans1)
			{ 
			
				
					$con = mysqli_connect("localhost","root","");
					mysqli_select_db($con,"bendovi");
			// 1.
			$qry = "SELECT * FROM tabela WHERE slika = '".$imeslike."'";
			$result = mysqli_query($con, $qry);
			if($result === FALSE) { die(mysqli_error($con));} //greske
			$row = mysqli_fetch_array($result);
			
				$imebenda = $row['ime'];
				
			$qry = "SELECT * FROM albumi WHERE imebenda = '".$imebenda."'";
			$result5 = mysqli_query($con, $qry);
			if($result5 === FALSE) { die(mysqli_error($con));} //greske	
			while($row = mysqli_fetch_array($result5))
			{
				$imealbuma = $row['imealbuma'];
				array_push($albumi, $imealbuma);
			}
			
			for($i=0; $i<count($albumi); $i++){
			$ime = $albumi[$i];
			
			$qry = "DELETE FROM pesme WHERE imealbuma = '".$ime."'";
			$result6 = mysqli_query($con, $qry);
			if($result6 === FALSE) { die(mysqli_error($con));} //greske
			
			}
				
			$qry = "DELETE FROM tabela WHERE slika = '".$imeslike."'";
			$result1 = mysqli_query($con, $qry);
			if($result1 === FALSE) { die(mysqli_error($con));} //greske
			
			
			$qry = "DELETE FROM albumi WHERE imebenda = '".$imebenda."'";
			$result2 = mysqli_query($con, $qry);
			if($result2 === FALSE) { die(mysqli_error($con));} //greske
			
						
			$qry = "DELETE FROM clanovi WHERE imebenda = '".$imebenda."'";
			$result3 = mysqli_query($con, $qry);
			if($result3 === FALSE) { die(mysqli_error($con));} //greske
			
			
			$qry = "DELETE FROM linkovi WHERE imebenda = '".$imebenda."'";
			$result4 = mysqli_query($con, $qry);
			if($result4 === FALSE) { die(mysqli_error($con));} //greske
			
			unlink($imeslike);
			
			
			
			
			header("Location:izbrisi.php");
			exit();
			
			
			
			
		
			}
		else if($answer == $ans2)
			{ 
			header("Location:izbrisi.php");
			exit();
			}
			
	//}		     
	

?>