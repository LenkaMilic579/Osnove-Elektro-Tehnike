<?php 
	session_start();
	$username1 = "";
	$password_1 = "";
	$errors = array();
	
	


	
	if (isset($_POST['login']))
	{	
		
		$k = 0;
		$username1 = $_POST['username'];
		$password_1 = $_POST['password_1'];
		$_SESSION["ime"] = $username1;
		
		


		if(empty($username1)){
			array_push($errors, 'Potrebno je da ukucate korisničko ime');
		}
		
		if(empty($password_1)){
			array_push($errors, 'Potrebno je da ukucate lozinku');
		}
		
		if(count($errors)==0){
			
			
			
			$con = mysqli_connect("localhost","root","");
			mysqli_select_db($con,"bendovi");
			$upit = "SELECT * FROM users";
			$sql = mysqli_query($con,$upit);
			
			
			while ($rows = mysqli_fetch_assoc($sql))//pravi array i smesta na rows var.
			{
			
			$u = $rows['username'];
			$p = $rows['password'];
			
			
			
			
			
					if($username1 == $u){
						if($password_1 == $p){
						$k = 1;
						$id = $rows['id'];
						$_SESSION["id"] = $id;
						
						
						}
					}
			}//kraj while
			
			mysqli_close($con);
			
			if($k==0){
				array_push($errors, 'Ukucali ste pogrešnu šifru ili korisnicko ime');
				
			}else{
			if($k==1){
			echo "Uspesno ste se ulogovali</br>";
			//za vuleta:
			if($username1=="admin"){header("Location:Korisnici_A.php"); exit();}
			
			header("Location:search1.php");
			exit();
			
			
			
			}
			}
		
			
			
			
		}
	}

?>