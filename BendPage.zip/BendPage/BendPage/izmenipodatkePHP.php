
<?php 


	$errors5 = array();
	

	
	if (isset($_POST['dodaj']))
	{
		
		
		$bio = $_POST['bio'];
		$imebenda= $_POST['name'];	
		
		if(empty($bio)){
			array_push($errors5, 'Morate uneti biografiju');
		}
	
		if(count($errors5)==0){
			
			$db = mysqli_connect("localhost", "root","","bendovi");
			
			$qry = "UPDATE tabela SET biografija= '".$bio."' WHERE ime='".$imebenda."'";
			$result1 = mysqli_query($db, $qry) or die(mysql_error()); 
			
		
			 ?>
			 </br></br></br></br></br></br></br></br></br></br></br>
			 <center>
			 <form method = "post" action = "idi_na_bendpage1.php" style="background:transparent; border: transparent; padding: 30px;">
			 	
			<input type="hidden" name="imebenda" value= "<?php echo $imebenda; ?>">
			<button type = "submit" name = "button" class="btn" style= " font-size: 30px; color:white; background-color:black;border-radius: 10px 10px 10px 10px;border-color: black;cursor:pointer; ">Završeno sa izmenama</button>
			</form><br>
			 </center>
			 <?php
			
			
		}
		mysqli_close($db);
	 
	}

?>
