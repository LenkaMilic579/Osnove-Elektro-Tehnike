
<!DOCTYPE html>
<html>
<head>
	<title>Izbrisi korisnika</title>
	<link rel = "stylesheet" type="text/css" href = "style.css">
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>
<?php require('sharewithall2.php'); echo "<br/><br/><br/><br/><br/>"; 
	
	
		
			$imekorisnika = $_POST['hiddenuser'];		
			

				?>
					
				<div class="header">
						<h2>Da li želite da obrišete korisnika <?php echo $imekorisnika; ?> ?</h2>
					</div>	
				<form method = "post" action = "izbrisiphp_A.php" >
						
				<div class= "input-group">			
					<center><button type = "submit" name = "izbrisi" class="btn" value="Da"  style="cursor: pointer;" >&nbsp&nbsp&nbsp&nbsp Da &nbsp&nbsp&nbsp&nbsp</button>
						 
					 <button type = "submit" name = "izbrisi" class="btn" value="Ne"  style="cursor: pointer;" >&nbsp&nbsp&nbsp&nbsp Ne &nbsp&nbsp&nbsp&nbsp </button></div>
					<input type="hidden" name="hiddenuser" value= "<?php echo $imekorisnika ?>">
					
				</center>
				
				
		
				</form>	
					
		<?php
				//}?>
	
	

	

</body>
</html>