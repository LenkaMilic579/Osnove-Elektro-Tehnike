<?php if (count($errors9) > 0): ?>
	<div class = "error">
		<?php foreach ($errors9 as $error): ?>
			<p><?php echo $error; ?> </p>
		<?php endforeach ?>
	</div>
<?php endif ?>