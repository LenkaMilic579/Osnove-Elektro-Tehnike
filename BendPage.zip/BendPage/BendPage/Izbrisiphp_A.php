<?php 

	
	//if (isset($_POST['submit']))
	//{
		$bendovi = array();
		$albumi = array();
		
		$ans1= 'Da';
		$ans2= 'Ne';
		$answer = $_POST['izbrisi']; //value of button1 or button2 in answer
		$imekorisnika = $_POST['hiddenuser'];
		if ($answer == $ans1)
			{ 
			
				
					$con = mysqli_connect("localhost","root","");
					mysqli_select_db($con,"bendovi");


			
			// 2.inadji id korisnika
			$qry = "SELECT * FROM users WHERE username = '".$imekorisnika."'";
			$result1 = mysqli_query($con, $qry);
			if($result1 === FALSE) { die(mysqli_error($con));} //greske
			$row = mysqli_fetch_array($result1);
			$id = $row['id'];
			$slika = $row['slika_ime'];
			
			$qry = "SELECT * FROM tabela WHERE id_vlasnika = '".$id."'";
			$result1 = mysqli_query($con, $qry);
			if($result1 === FALSE) { die(mysqli_error($con));} //greske
			while($row = mysqli_fetch_array($result1))
			{
				
				$ime = $row['ime'];
				array_push($bendovi, $ime);
			}
			
			
			for($i=0; $i<count($bendovi); $i++){
			$imebenda = $bendovi[$i];

			$qry = "SELECT * FROM tabela WHERE ime = '".$imebenda."'";
			$result44= mysqli_query($con, $qry);
			if($result44 === FALSE) { die(mysqli_error($con));} //greske
			$row = mysqli_fetch_array($result44);
			$imeslike = $row['slika'];	


			$qry = "SELECT * FROM albumi WHERE imebenda = '".$imebenda."'";
			$result5 = mysqli_query($con, $qry);
			if($result5 === FALSE) { die(mysqli_error($con));} //greske
				
			while($row = mysqli_fetch_array($result5))
			{
				$imealbuma = $row['imealbuma'];
				array_push($albumi, $imealbuma);
			}
			
			for($i=0; $i<count($albumi); $i++){
			$ime = $albumi[$i];
			
			$qry = "DELETE FROM pesme WHERE imealbuma = '".$ime."'";
			$result6 = mysqli_query($con, $qry);
			if($result6 === FALSE) { die(mysqli_error($con));} //greske
			
			}		
			
			
			$qry = "DELETE FROM albumi WHERE imebenda = '".$imebenda."'";
			$result3 = mysqli_query($con, $qry);
			if($result3 === FALSE) { die(mysqli_error($con));} 
			
			$qry = "DELETE FROM clanovi WHERE imebenda = '".$imebenda."'";
			$result3 = mysqli_query($con, $qry);
			if($result3 === FALSE) { die(mysqli_error($con));} 
			
			$qry = "DELETE FROM linkovi WHERE imebenda = '".$imebenda."'";
			$result3 = mysqli_query($con, $qry);
			if($result3 === FALSE) { die(mysqli_error($con));} 
			
			$qry = "DELETE FROM tabela WHERE ime = '".$imebenda."' ";
			$result2 = mysqli_query($con, $qry);
			if($result2 === FALSE) { die(mysqli_error($con));} //greske
			mysqli_fetch_array($result2);			
			
			unlink($imeslike);
			
			}
			
			
			// 2.izbrisi tog korisnika
			$qry = "DELETE FROM users WHERE username = '".$imekorisnika."' AND id = '".$id."'";
			$result2 = mysqli_query($con, $qry);
			if($result2 === FALSE) { die(mysqli_error($con));} //greske
			mysqli_fetch_array($result2);	

			unlink($slika);
			
			
			header("Location:Korisnici_A.php");
			exit();
			
		
			}
		else if($answer == $ans2)
			{ 
			header("Location:Korisnici_A.php");
			exit();
			}
			
	//}		     
	

?>