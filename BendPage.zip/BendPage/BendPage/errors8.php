<?php if (count($errors8) > 0): ?>
	<div class = "error">
		<?php foreach ($errors8 as $error): ?>
			<p><?php echo $error; ?> </p>
		<?php endforeach ?>
	</div>
<?php endif ?>