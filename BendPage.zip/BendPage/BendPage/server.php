<?php 

	$username = "";
	$email = "";
	$errors = array();
	

	
	if (isset($_POST['register']))
	{
		
		
		$username = $_POST['username'];
		$email = $_POST['email'];
		$password_1 = $_POST['password_1'];
		$password_2 = $_POST['password_2'];
		
		if(empty($username)){
			array_push($errors, 'Morate uneti korisičko ime');
		}
		if(empty($email)){
			array_push($errors, 'Morate uneti email');
		}
		if(empty($password_1)){
			array_push($errors, 'Morate uneti lozinku');
		}
		
		if($password_1 != $password_2){
			array_push($errors, "Lozinke se ne slažu");
		}
		if(count($errors)==0){
			
			$db = mysqli_connect("localhost","root","");
			mysqli_select_db($db,"bendovi");
			

			//$password = md5($password_1); //encript password before storing in database(security)
			$sql = "INSERT INTO users(username,email,password,slika_ime) VALUES('$username','$email','$password_1','1.png')";
			mysqli_query($db, $sql);
			
			
			
			
			$sql1 = "SELECT * FROM users WHERE username = '".$username."'";
			$result1 = mysqli_query($db, $sql1);
			if($result1 === FALSE) { die(mysqli_error($db));} 
			while($row = mysqli_fetch_array($result1))
			{
				$id = $row['id'];

			}
			mysqli_close($db);
			
			header("Location:login.php");
		    
			exit();
			
		}
		
		
	}

?>