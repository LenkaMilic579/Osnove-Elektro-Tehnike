</br></br></br></br></br>
<?php 


	$errors6 = array();
	

	
	if (isset($_POST['dodaj']))
	{
		
		
		$imealbuma = $_POST['imealbuma'];
		$brojpesama= $_POST['brojpesama'];	
		$imebenda= $_POST['name'];
		
		if(empty($imealbuma)){
			array_push($errors6, 'Morate uneti ime album.');
		}
		if(empty($brojpesama)){
			array_push($errors6, 'Morate uneti broj pesama koje zelite da dodate.');
		}
	
		if(count($errors6)==0){
			
		
			 ?>
			 
			
			<div class="header">
			<h2><?php echo $imealbuma; ?></h2>
			</div>
	
		<form method = "post" action = "izmenidiskografijuphp.php" >
		<?php 
		for($i=0; $i<$brojpesama; $i++){
		?>
		
		<div class= "input-group">
			<label>Ime pesme</label>
			<input type = "text" name = "br[]">
		</div>	
			 
		<?php
		}
		?>
		<div class= "input-group">
			<button type = "submit" name = "dodaj" class="btn" style="cursor: pointer;">Potvrdi</button>
		</div>
		<input type="hidden" name="pesme1" value= "<?php echo $brojpesama ?>">
		<input type="hidden" name="name" value= "<?php echo $imebenda ?>">
		<input type="hidden" name="album" value= "<?php echo $imealbuma ?>">
		
		</form>
		
		<?php
			
			
	}
		
	 
	}

?>