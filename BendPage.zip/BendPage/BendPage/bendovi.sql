-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 13, 2018 at 03:14 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bendovi`
--

-- --------------------------------------------------------

--
-- Table structure for table `albumi`
--

DROP TABLE IF EXISTS `albumi`;
CREATE TABLE IF NOT EXISTS `albumi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imebenda` varchar(255) NOT NULL,
  `imealbuma` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `clanovi`
--

DROP TABLE IF EXISTS `clanovi`;
CREATE TABLE IF NOT EXISTS `clanovi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imebenda` varchar(255) NOT NULL,
  `clan` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `linkovi`
--

DROP TABLE IF EXISTS `linkovi`;
CREATE TABLE IF NOT EXISTS `linkovi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idbenda` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pesme`
--

DROP TABLE IF EXISTS `pesme`;
CREATE TABLE IF NOT EXISTS `pesme` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `imealbuma` varchar(255) NOT NULL,
  `imepesme` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tabela`
--

DROP TABLE IF EXISTS `tabela`;
CREATE TABLE IF NOT EXISTS `tabela` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_vlasnika` int(11) NOT NULL,
  `ime` varchar(255) NOT NULL,
  `grad` varchar(255) NOT NULL,
  `zanr` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `godosnivanja` int(4) NOT NULL,
  `biografija` varchar(255) NOT NULL,
  `imeslike` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `slika_ime` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `slika_ime`) VALUES
(21, 'Dragan Aksic', 'drgn999999@jebemtizenomajku.com', '123', '1.png');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
