<html>
<head>
<title>MAJBENDPEJDz</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<meta name="viewport" content="width=device-width, initial-scale=1">


</head>
<body>
<?php  require('sharewithall2.php');	?>
<!-- Page content -->
<div class="w3-content" style="max-width:2000px;margin-top:46px">
<form class="example" method= "post" action="platforma1.php" style="margin:300px 750px;max-width:900px">
  <input type="text" placeholder="Pretraži..." name="search2">
  <button type="submit" name = "posalji"><i class="fa fa-search"></i></button>
</form>
<!-- End Page Content -->
</div>



</body>
</html>