//Ako je pritisnuto dugme za biografiju
		if (isset($_POST['bio']))
		{		
		$imebenda = $podaci_o_bendu[0];
		$bio =  $podaci_o_bendu[4];
		
		?>
			
		<div align="center" style="vertical-align:bottom">
		<div align="center" style="vertical-align:bottom">
		<table id="t01" >
		<tr>
		<th>Biografija benda</th>
		</tr>
		<tr>
		<td><?php echo $bio; ?></td>
		</tr>
		</table><div><div>
		
		<?php
		}
			
		
		//Ako je pritisnuto dugme za diskografiju
		if (isset($_POST['disko']))
		{				
		?>
			
		<div align="center" style="vertical-align:bottom">
		<div align="center" style="vertical-align:bottom">
		<table id="t01" >
		<tr>
		<th>Diskografija benda</th>
		</tr>
		<tr>
		<!--Za svako ime albuma napravi novu kolonu-->
		<?php for($k=0; $k<count($albumi); $k++){ 
		if ( ! isset($albumi[$k])) {
					$album = null;
					}
		$album = $albumi[$k];?>
		<td><?php echo $album; ?></td>
		<!--Za svako ime albuma napravi novu kolonu za pesme-->
		<?php for($j=0; $j<$broji; $j++)
		{ if($pesme[$j][0] == $album)
			{	
				//if ( ! isset($pesme[$j][$z])) {
				//$trpesma = null;
				//}
				$trpesma = $pesme[$j][1];
				?>  <tr><td><?php echo $trpesma; ?></td></tr> <?php
				
			
			}
		}
		}?>  
		</tr>
		</table><div><div>
		
		<?php
		}
		
		//Ako je pritisnuto dugme za clanove
		if (isset($_POST['clanovi']))
		{		
		
		?>
			
		<div align="center" style="vertical-align:bottom">
		<div align="center" style="vertical-align:bottom">
		<table id="t01" >
		<tr>
		<th>Clanovi benda</th>
		</tr>
		<tr>
		<?php for($i=0; $i<count($clanovi); $i++)
		{ $clan = $clanovi[$i]; 
		?> <td><?php echo $clan."<br/>";?></td> 
		<?php } ?>
		</tr>
		</table><div><div>
		
		<?php
		}
		
		if (isset($_POST['linkovi']))
		{		
		
		?>
			
		<div align="center" style="vertical-align:bottom">
		<div align="center" style="vertical-align:bottom">
		<table id="t01" >
		<tr>
		<th>Linkovi</th>
		</tr>
		<tr>
		<?php for($i=0; $i<count($linkovi); $i++)
		{ $link = $linkovi[$i]; 
		?> <td><?php echo $link."<br/>";?></td> 
		<?php } ?>
		</tr>
		</table><div><div>
		
		<?php
		}
		
		