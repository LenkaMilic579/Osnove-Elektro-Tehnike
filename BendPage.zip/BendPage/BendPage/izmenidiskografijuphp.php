<?php 
require('sharewithall2.php');

	$errors7 = array();
	$pesme = array();
	

	
	if (isset($_POST['dodaj']))
	{
		
		
		$brpesama = $_POST['pesme1'];
		$imebenda = $_POST['name'];
		$imealbuma = $_POST['album'];
		
		for($i=0;$i<$brpesama;$i++)	{
		if(empty($_POST["br"][$i])){
					array_push($errors7, 'Morate uneti ime pesme');
					}
		}		
		
	
		if(count($errors7)==0){
			
			$db = mysqli_connect("localhost", "root","","bendovi");
			
			$qry = "INSERT INTO albumi(imebenda,imealbuma) VALUES('$imebenda','$imealbuma')";
			mysqli_query($db, $qry);
			
			for($i=0;$i<$brpesama;$i++)	{
				$pesma = $_POST["br"][$i];
					
				$qry = "INSERT INTO pesme(imealbuma,imepesme) VALUES('$imealbuma','$pesma')";
				mysqli_query($db, $qry);
			
			}
			mysqli_close($db);
			
			
			
			 ?>
			 
			 <form method = "post" action = "idi_na_bendpage1.php" >
			<input type="hidden" name="imebenda" value= "<?php echo $imebenda; ?>"></br></br></br></br></br></br></br></br></br></br></br>
			<button type = "submit" name = "button" class="btn" style= "margin:0px 0px 0px 810px; float:left; font-size: 20px; color:white; background-color:black;border-radius: 10px 10px 10px 10px;border-color: black;cursor: pointer; "><h2>Završeno sa izmenama</h2></button>
		
			</form><br>
			 
			 <?php
		}
			
		}
		
	 
	

?>