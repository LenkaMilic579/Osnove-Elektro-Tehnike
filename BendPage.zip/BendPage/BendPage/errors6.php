<?php if (count($errors6) > 0): ?>
	<div class = "error">
		<?php foreach ($errors6 as $error): ?>
			<p><?php echo $error; ?> </p>
		<?php endforeach ?>
	</div>
<?php endif ?>