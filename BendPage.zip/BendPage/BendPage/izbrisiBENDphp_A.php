<?php 

	
	//if (isset($_POST['submit']))
	//{
		$albumi = array();
		$ans1= 'Da';
		$ans2= 'Ne';
		$answer = $_POST['izbrisi']; //value of button1 or button2 in answer
		$imebenda = $_POST['hiddenbend'];
		if ($answer == $ans1)
			{ 
			
				
					$con = mysqli_connect("localhost","root","");
					mysqli_select_db($con,"bendovi");

			$qry = "SELECT * FROM tabela WHERE ime = '".$imebenda."'";
			$result44= mysqli_query($con, $qry);
			if($result44 === FALSE) { die(mysqli_error($con));} //greske
			$row = mysqli_fetch_array($result44);
			
			$imeslike = $row['slika'];		
					
			$qry = "SELECT * FROM albumi WHERE imebenda = '".$imebenda."'";
			$result4 = mysqli_query($con, $qry);
			if($result4 === FALSE) { die(mysqli_error($con));} //greske
			while($row = mysqli_fetch_array($result4))
			{
				
				$imealbuma = $row['imealbuma'];
				array_push($albumi, $imealbuma);

					
			}
			
				
			for($i=0; $i<count($albumi); $i++){
			$ime = $albumi[$i];
			$qry = "DELETE FROM pesme WHERE imealbuma = '".$ime."'";
			$result5 = mysqli_query($con, $qry);
			if($result5 === FALSE) { die(mysqli_error($con));} //greske
			}
			
			
			// 3.izbrisi sve njegove bendove
			$qry = "DELETE FROM tabela WHERE ime = '".$imebenda."'";
			$result = mysqli_query($con, $qry);
			if($result === FALSE) { die(mysqli_error($con));} //greske
			
			
			$qry = "DELETE FROM albumi WHERE imebenda = '".$imebenda."'";
			$result1 = mysqli_query($con, $qry);
			if($result1 === FALSE) { die(mysqli_error($con));} //greske
			
						
			$qry = "DELETE FROM clanovi WHERE imebenda = '".$imebenda."'";
			$result2 = mysqli_query($con, $qry);
			if($result2 === FALSE) { die(mysqli_error($con));} //greske
			
			
			$qry = "DELETE FROM linkovi WHERE imebenda = '".$imebenda."'";
			$result3 = mysqli_query($con, $qry);
			if($result3 === FALSE) { die(mysqli_error($con));} //greske
			
			unlink($imeslike);
	
			
			
			header("Location:Bendovi_A.php");
			exit();
			
		
			}
		else if($answer == $ans2)
			{ 
			header("Location:Bendovi_A.php");
			exit();
			}
			
	//}		     
	

?>