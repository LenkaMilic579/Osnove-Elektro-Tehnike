sbit ENA1 at LATD0_bit;
sbit DIR1 at LATD1_bit;
sbit PLS1 at LATD2_bit;

sbit ENA2 at LATD3_bit;
sbit DIR2 at LATD4_bit;
sbit PLS2 at LATD5_bit;

sbit ENA3 at LATB3_bit;
sbit DIR3 at LATB4_bit;
sbit PLS3 at LATB5_bit;

sbit desno1 at LATC3_bit;
sbit pravo1 at LATC4_bit;
sbit levo1 at LATC5_bit;

sbit def at LATB2_bit;

int i;
int pom;
int desno0; int pravo0; int levo0;
unsigned cnt;
//unsigned long d; unsigned long p; unsigned long l;
unsigned k;

void interrupt() {
  if (TMR0IF_bit) {
    cnt++;                 // increment counter
    TMR0IF_bit = 0;        // clear TMR0IF
    TMR0L = 1;             //inicijalna vrednost
  }
}

void rad_motora()
{
  switch(LATB7_bit)
 {
  case 0:
          ENA1 = 0;
          ENA2 = 0;

  break;
   case 1:
          ENA1 = 1;
          ENA2 = 1;

 break;
 }
  return;
}

void direction()
{
  switch(LATB6_bit)
 {
  case 0:
          DIR1 = 0;
          DIR2 = 0;

  break;
   case 1:
          DIR1 = 1;
          DIR2 = 1;

 break;
 }
  return;
}

void wait(){
     Delay_ms(8346);
}
void dalje(){
  LATB6_bit = 1;
}

void levo() {

     //jedno odbrojavanje tajmera do 5,25 sec

     do {
          if (cnt >= 5)           //ogranici na priblizno 5,250,000 ms
            {
               for(i = 0; i < 629; i++)
                {
                 // wheels
                PLS1 = ~PLS1;      //Motor 1 on
                PLS2 = 0;          //Motor 2 off
                wait();            //Delay = 8400 ms; ____(delay * 629)/1000 = 5,25 s
                }
              cnt = 0;
           }
         pom = 0;
        }while(pom==1);


     return;
}


void desno(){

     do {
          if (cnt >= 5)           //ogranici na priblizno 5,250,000 ms
            {
               for(i = 0; i < 629; i++)
                {
                 // wheels
                PLS2 = ~PLS2;      //Motor 2 on
                PLS1 = 0;          //Motor 1 off
                wait();            //Delay = 8400 ms; ____(delay * 629)/1000 = 5,25 s
                }
              cnt = 0;
           }
        pom = 0;
        }while(pom==1);


     return;
}

void rotacija(){  // 90 stepeni

     do {
          if (cnt >= 5)           //ogranici na priblizno 5,250,000 ms
            {
               for(i = 0; i < 314; i++)
                {

                PLS3 = ~PLS3;      //Motor 2 on
                wait();            //Delay = 8400 ms; ____(delay * 629)/1000 = 5,25 s
                }
              cnt = 0;
           }
        pom = 0;
        }while(pom==1);


     return;
}






void main() {
  ADCON1 = 0x0F;                // All AN pins as digitall
  CMCON  = 0x07;                // Turn off comparators

  TRISA = 0xFF;                 // set PORTA as input
  TRISD = 0;                    // set PORTD as output
  PORTD = 0;
  TRISB = 0;                    // set PORTB as output
  TRISC = 0xFF;                 // set PORTC as input
  TRISE0_bit = 1;               // set RE0 as input
  TRISE1_bit = 1;               // set RE1 as input

 // tmr0 interrupt______

  T0CON = 0x84;       // Assign prescaler to TMR0  ______1:32 , tmro pesc not assigned
  TMR0L  = 1;              // Timer0 initial value, clear ____external interrupr error or tmro reg overflow
  INTCON = 0xA0;           // Enable TMRO interrupt     a/d   Disable INTO external interrpt
  cnt = 0;                 // Initialize cnt
  pom = 1;
  //d = 0;
  //p = 0;
  //l = 0;
  k = 1;

 // out init

 ENA1 = 0;
 ENA2 = 0;
 ENA3 = 0;

 PLS1 = 1;
 PLS2 = 1;
 PLS3 = 1;

 DIR1 = 1;
 DIR2 = 1;
 DIR3 = 0;

      while(1){
                LATD6_bit = !RE1_bit;     //   Levo
                LATD7_bit = !RE0_bit;     //   Desno
                LATB7_bit = !RC0_bit;     //   1 - motors on
                                          //   0 - motors off
                LATB6_bit = !RC1_bit;    //  direction switch
                def = !RC2_bit;          //  default switch
                rad_motora();
                direction();

             if(def == 0){
             if(ENA1 == 1 && ENA2 == 1) // motors on
             {


                if(LATD6_bit == 1){  levo();}     //ako je pritisnut taster Levo - RE0_bit
                if(LATD7_bit == 1){  desno();}    //ako je pritisnut taster Desno - RE1_bit

                PLS1 = ~PLS1;           //inace kretanje napred
                PLS2 = ~PLS2;
                wait();
             }
             }

             else if (def == 1){
                   if((k % 2)== 1 ){   //okretanje senzora na levo
                //primi info 1
                    ENA1 = 0;
                    ENA2 = 0;
                    ENA3 = 1;
                    PLS3 = 1;
                    wait();
                    dalje();
                    if(!LATC3_bit == 1) {desno0 = 1;}
                    rotacija();
                    wait();
                    dalje();
                    if(!LATC4_bit == 1) {pravo0 = 1;}
                    rotacija();
                    wait();
                    dalje();
                    if(!LATC5_bit == 1) {levo0 = 1;}

                    ENA1 = 1;
                    ENA2 = 1;
                    ENA3 = 0;

                    if (desno0 == 1 && pravo0 ==0 && levo0 == 0){ PLS1 = ~PLS1;  PLS2 = ~PLS2; wait();}
                    if (desno0 == 0 && pravo0 ==1 && levo0 == 0){desno();}
                    if (desno0 == 1 && pravo0 ==1 && levo0 == 0){levo();}
                    if (desno0 == 0 && pravo0 ==0 && levo0 == 1){desno();}
                    if (desno0 == 1 && pravo0 ==0 && levo0 == 1){PLS1 = ~PLS1;  PLS2 = ~PLS2; wait(); }
                    if (desno0 == 0 && pravo0 ==1&& levo0 == 1){desno();}
                    if (desno0 == 1 && pravo0 ==1&& levo0 == 1){desno(); desno();}
                    k = k + 1;
                }
                else if((k % 2) == 0) {
                    ENA1 = 0;
                    ENA2 = 0;
                    ENA3 = 1;
                    PLS3 = 0;

                    wait();
                    dalje();
                    if(!LATC5_bit == 1)  {levo0 = 1;}
                    rotacija();
                    wait();
                    dalje();
                    if(!LATC4_bit == 1)  {pravo0 = 1;}
                    rotacija();
                    wait();
                    dalje();
                    if(!LATC3_bit == 1) {desno0 = 1;}

                    ENA1 = 1;
                    ENA2 = 1;
                    ENA3 = 0;

                    if (desno0 == 1 && pravo0 ==0 && levo0 == 0){ PLS1 = ~PLS1;  PLS2 = ~PLS2; wait();}
                    if (desno0 == 0 && pravo0 ==1 && levo0 == 0){desno();}
                    if (desno0 == 1 && pravo0 ==1 && levo0 == 0){levo();}
                    if (desno0 == 0 && pravo0 ==0 && levo0 == 1){desno();}
                    if (desno0 == 1 && pravo0 ==0 && levo0 == 1){PLS1 = ~PLS1;  PLS2 = ~PLS2; wait(); }
                    if (desno0 == 0 && pravo0 ==1 && levo0 == 1){desno();}
                    if (desno0 == 1 && pravo0 ==1 && levo0 == 1){desno(); desno();}
                    k = k + 1;
                }






             }

             }


}