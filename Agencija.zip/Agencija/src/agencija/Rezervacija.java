/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package agencija;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author LENA
 */
public class Rezervacija {
   // String[] dest;
    ArrayList<String> dest = new ArrayList<String>();
    
public Rezervacija(ArrayList<String> dest1)
{
    dest = dest1;
}
    
    
public boolean reserve(int ind)
{
    String mark = "R";
    if(dest.get(ind-1) == mark)
    { System.out.println("Za odabranu destinaciju nema slobonih karata");
        return false; }
    else 
    {   
        return true;
                
    }
}


}
